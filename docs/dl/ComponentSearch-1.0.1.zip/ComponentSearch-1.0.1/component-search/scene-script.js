'use strict';

// Runs inside the Scene process. `cc`, `_Scene` and the live scene graph are available here.

const SCRIPT_MENU_PREFIX = 'i18n:MAIN_MENU.component.scripts/';

function safeKeys (obj) {
  if (obj == null) {
    return null;
  }
  try {
    return Object.keys(obj).sort();
  } catch (err) {
    return ['<keys unavailable: ' + err.message + '>'];
  }
}

// Visual components that do NOT extend cc.RenderComponent and would otherwise
// be misfiled as plain engine components.
const VISUAL_EXTRAS = ['cc.RichText', 'cc.LabelOutline', 'cc.LabelShadow'];

/**
 * Four buckets, matching how you actually read a node:
 *   script  - project code (the thing you wrote)
 *   render  - draws pixels
 *   engine  - everything else built in (layout, interaction, playback)
 *   missing - broken script reference
 */
function classifyComponent (cls, className) {
  if (className === 'cc.MissingScript') {
    return 'missing';
  }
  if (isProjectScript(cls)) {
    return 'script';
  }
  if (VISUAL_EXTRAS.indexOf(className) >= 0) {
    return 'render';
  }
  if (cc.RenderComponent && cc.js.isChildClassOf(cls, cc.RenderComponent)) {
    return 'render';
  }
  return 'engine';
}

function isProjectScript (cls) {
  // CCClass.js sets prototype.__scriptUuid only for user script components.
  return !!(cls && cls.prototype && cls.prototype.__scriptUuid);
}

/**
 * The class that makes a component exclusive, or '' when it allows duplicates.
 *
 * base-node.js:865 checks `this.getComponent(ctor._disallowMultiple)` - the BASE
 * class, not the component itself. cc.RenderComponent declares disallowMultiple,
 * so cc.Sprite._disallowMultiple === cc.RenderComponent, and a node already
 * carrying cc.Mask (same base) rejects cc.Sprite. Comparing class names alone
 * misses that entire family of conflicts.
 */
function exclusiveGroupOf (cls) {
  const base = cls && cls._disallowMultiple;
  return base ? cc.js.getClassName(base) : '';
}

// Engine menu categories, e.g. "i18n:MAIN_MENU.component.renderers/Sprite" -> "Renderer / Sprite".
const MENU_PREFIX = 'i18n:MAIN_MENU.component.';
const MENU_CATEGORIES = {
  renderers: 'Renderer',
  ui: 'UI',
  others: 'Other',
  scripts: 'Script',
  collider: 'Collider',
  physics: 'Physics',
  mesh: 'Mesh',
};

function prettifyMenuPath (path) {
  if (!path || path.indexOf(MENU_PREFIX) !== 0) {
    return path || '';
  }
  const rest = path.slice(MENU_PREFIX.length);
  const slash = rest.indexOf('/');
  if (slash < 0) {
    return rest;
  }
  const category = rest.slice(0, slash);
  return (MENU_CATEGORIES[category] || category) + ' / ' + rest.slice(slash + 1);
}

/**
 * Collect every addable component - project scripts AND engine components.
 *
 * cc._componentMenuItems is exactly what the built-in Add Component button offers,
 * so using it as the source gives parity with that menu. Two things to know:
 *  - CCClass.js:340-350 auto-registers every user script here as
 *    `<SCRIPT_MENU_PREFIX><ClassName>` on top of any explicit @menu, so a class
 *    can appear twice - dedupe by class.
 *  - Modules excluded in project.json (Physics, Collider, 3D, Spine...) never
 *    register, so they simply will not show up. That is correct behaviour.
 */
function collectProjectComponents () {
  const byClass = new Map();

  const menuItems = cc._componentMenuItems || [];
  for (let i = 0; i < menuItems.length; ++i) {
    const item = menuItems[i];
    const cls = item.component;
    if (!cls) {
      continue;
    }

    const className = cc.js.getClassName(cls);
    const isProject = isProjectScript(cls);
    let entry = byClass.get(cls);
    if (!entry) {
      entry = {
        className: className,
        displayName: isProject ? className : className.replace(/^cc\./, ''),
        isProject: isProject,
        kind: classifyComponent(cls, className),
        exclusiveGroup: exclusiveGroupOf(cls),
        scriptUuid: isProject ? cls.prototype.__scriptUuid : '',
        menuPath: '',
        source: 'menuItems',
      };
      byClass.set(cls, entry);
    }

    // Prefer an explicit @menu path over the auto-generated "scripts/" one.
    const path = item.menuPath || '';
    if (path.indexOf(SCRIPT_MENU_PREFIX) !== 0) {
      entry.menuPath = prettifyMenuPath(path);
    }
  }

  // Cross-check the raw class registry for project scripts only. Engine classes are
  // deliberately not swept here - the registry also holds abstract bases
  // (cc.Component, cc.RenderComponent) that must never be offered as addable.
  const registryOnly = [];
  const registered = cc.js._registeredClassNames || {};
  for (const name in registered) {
    const cls = registered[name];
    if (typeof cls !== 'function') {
      continue;
    }
    if (!cc.js.isChildClassOf(cls, cc.Component)) {
      continue;
    }
    if (!isProjectScript(cls)) {
      continue;
    }
    if (!byClass.has(cls)) {
      registryOnly.push(name);
      byClass.set(cls, {
        className: name,
        displayName: name,
        isProject: true,
        kind: 'script',
        exclusiveGroup: exclusiveGroupOf(cls),
        scriptUuid: cls.prototype.__scriptUuid,
        menuPath: '',
        source: 'registry',
      });
    }
  }

  const list = Array.from(byClass.values()).sort((a, b) => {
    if (a.isProject !== b.isProject) {
      return a.isProject ? -1 : 1;
    }
    return a.displayName.localeCompare(b.displayName);
  });

  return {
    list: list,
    registryOnly: registryOnly,
    projectCount: list.filter(c => c.isProject).length,
    engineCount: list.filter(c => !c.isProject).length,
  };
}

/**
 * Tell the editor the scene changed, so it prompts to save on close.
 * Only calls things we can confirm exist - a speculative IPC to an unknown
 * message name would just spam the console on every add.
 */
function markSceneDirty () {
  if (typeof _Scene === 'undefined' || !_Scene) {
    return 'no _Scene';
  }
  if (typeof _Scene.setDirty === 'function') {
    _Scene.setDirty(true);
    return '_Scene.setDirty';
  }
  if (_Scene.Undo && typeof _Scene.Undo.commit === 'function') {
    return 'via undo commit';
  }
  return 'none';
}

/** Every function-valued key on _Scene, so one probe run tells us the real API. */
function listSceneFunctions () {
  if (typeof _Scene === 'undefined' || !_Scene) {
    return null;
  }
  const out = [];
  try {
    for (const key in _Scene) {
      const kind = typeof _Scene[key];
      if (kind === 'function') {
        out.push(key + '()');
      } else if (kind === 'object' && _Scene[key]) {
        out.push(key + '{' + safeKeys(_Scene[key]).join(',') + '}');
      }
    }
  } catch (err) {
    return ['<enumeration failed: ' + err.message + '>'];
  }
  return out.sort();
}

function describeUndo () {
  const info = {
    sceneGlobalExists: typeof _Scene !== 'undefined',
    sceneKeys: null,
    undoKeys: null,
    undoMethods: {},
  };

  if (!info.sceneGlobalExists) {
    return info;
  }

  info.sceneKeys = safeKeys(_Scene);

  const undo = _Scene.Undo;
  if (!undo) {
    return info;
  }

  info.undoKeys = safeKeys(undo);
  const candidates = [
    'recordNode', 'recordAdd', 'recordDeleteNode', 'recordObject',
    'commit', 'cancel', 'undo', 'redo', 'clear', 'add',
  ];
  for (let i = 0; i < candidates.length; ++i) {
    info.undoMethods[candidates[i]] = typeof undo[candidates[i]];
  }
  return info;
}

/**
 * Add a component and try to make the operation undoable.
 * Reports which undo strategy actually ran so the spike can confirm it.
 */
function addComponentWithUndo (nodeUuid, className) {
  const node = cc.engine.getInstanceById(nodeUuid);
  if (!node) {
    return { ok: false, reason: 'node not found for uuid ' + nodeUuid };
  }

  const cls = cc.js.getClassByName(className);
  if (!cls) {
    return { ok: false, reason: 'class not registered: ' + className };
  }

  // Check the exclusive-group conflict ourselves. Calling addComponent and letting it
  // fail would work, but the engine logs cc.errorID(3806) first and that error noise
  // is exactly what we do not want in the console on a routine misclick.
  if (cls._disallowMultiple) {
    const existing = node.getComponent(cls._disallowMultiple);
    if (existing) {
      const existingName = cc.js.getClassName(existing.constructor);
      return {
        ok: false,
        reason: existingName === className
          ? node.name + ' already has ' + className
          : className + ' conflicts with ' + existingName + ' on ' + node.name,
      };
    }
  }

  const undo = (typeof _Scene !== 'undefined') ? _Scene.Undo : null;
  let undoStrategy = 'none';

  if (undo && typeof undo.recordNode === 'function') {
    undo.recordNode(nodeUuid);
    undoStrategy = 'recordNode';
  }

  const comp = node.addComponent(cls);
  if (!comp) {
    if (undo && typeof undo.cancel === 'function') {
      undo.cancel();
    }
    return { ok: false, reason: 'addComponent returned null (disallowMultiple or requireComponent conflict)', undoStrategy: undoStrategy };
  }

  if (undoStrategy === 'recordNode' && typeof undo.commit === 'function') {
    undo.commit();
    undoStrategy = 'recordNode+commit';
  }

  const dirtyStrategy = markSceneDirty();

  if (cc.engine && typeof cc.engine.repaintInEditMode === 'function') {
    cc.engine.repaintInEditMode();
  }

  return {
    ok: true,
    className: className,
    nodeUuid: nodeUuid,
    undoStrategy: undoStrategy,
    dirtyStrategy: dirtyStrategy,
  };
}

function reply (event, err, data) {
  if (event && typeof event.reply === 'function') {
    event.reply(err, data);
    return;
  }
  Editor.log('[component-search] no event.reply available: ' + JSON.stringify(data));
}

module.exports = {
  'probe' (event) {
    let payload;
    try {
      const collected = collectProjectComponents();
      payload = {
        ccAvailable: typeof cc !== 'undefined',
        componentMenuItemsTotal: (cc._componentMenuItems || []).length,
        projectComponentCount: collected.projectCount,
        engineComponentCount: collected.engineCount,
        foundOnlyInRegistry: collected.registryOnly,
        sampleComponents: collected.list.slice(0, 15),
        withExplicitMenu: collected.list.filter(c => c.menuPath).length,
        undo: describeUndo(),
        sceneApi: listSceneFunctions(),
        sceneEditorKeys: safeKeys(typeof Editor !== 'undefined' ? Editor : null),
        selectionInScene: (typeof Editor !== 'undefined' && Editor.Selection)
          ? Editor.Selection.curSelection('node')
          : '<Editor.Selection unavailable>',
      };
    } catch (err) {
      reply(event, err.stack || err.message, null);
      return;
    }
    reply(event, null, payload);
  },

  'list-components' (event) {
    try {
      reply(event, null, collectProjectComponents().list);
    } catch (err) {
      reply(event, err.stack || err.message, null);
    }
  },

  /** Which components already sit on the selected nodes, and which of those refuse duplicates. */
  'node-components' (event, args) {
    try {
      const uuids = (args && args.nodeUuids) || [];
      const names = [];
      const present = [];
      const seen = new Set();

      // exclusive group -> the component name occupying it. Tracked per node so we can
      // tell "blocked everywhere" (hard block) from "blocked on some" (still worth trying).
      const perNodeGroups = [];
      const occupiedBy = {};

      for (let i = 0; i < uuids.length; ++i) {
        const node = cc.engine.getInstanceById(uuids[i]);
        if (!node) {
          continue;
        }
        names.push(node.name);

        const groups = new Set();
        const comps = node._components || [];
        for (let c = 0; c < comps.length; ++c) {
          const cls = comps[c] && comps[c].constructor;
          if (!cls) {
            continue;
          }
          const name = cc.js.getClassName(cls);
          if (!seen.has(name)) {
            seen.add(name);
            present.push({ name: name, kind: classifyComponent(cls, name) });
          }
          const group = exclusiveGroupOf(cls);
          if (group) {
            groups.add(group);
            if (!occupiedBy[group]) {
              occupiedBy[group] = name;
            }
          }
        }
        perNodeGroups.push(groups);
      }

      const anyGroups = new Set();
      perNodeGroups.forEach(g => g.forEach(x => anyGroups.add(x)));
      const allGroups = Array.from(anyGroups).filter(
        g => perNodeGroups.length > 0 && perNodeGroups.every(set => set.has(g))
      );

      reply(event, null, {
        names: names,
        present: present,
        occupiedBy: occupiedBy,
        blockedGroupsAny: Array.from(anyGroups),
        blockedGroupsAll: allGroups,
      });
    } catch (err) {
      reply(event, err.stack || err.message, null);
    }
  },

  'add-component' (event, args) {
    try {
      const uuids = args.nodeUuids || [args.nodeUuid];
      const results = uuids.map(uuid => addComponentWithUndo(uuid, args.className));
      reply(event, null, {
        className: args.className,
        added: results.filter(r => r.ok).length,
        failed: results.filter(r => !r.ok),
        undoStrategy: results.length ? results[0].undoStrategy : 'none',
        dirtyStrategy: results.length ? results[0].dirtyStrategy : 'none',
      });
    } catch (err) {
      reply(event, err.stack || err.message, null);
    }
  },
};
