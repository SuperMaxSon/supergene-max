// Search + autocomplete panel for adding project script components to selected nodes.

const MAX_RESULTS = 40;
const RECENT_LIMIT = 8;
const RECENT_BONUS = 25;     // nudge previously used components up the ranking
const PRESENT_PENALTY = 20;  // sink components the node already has, but keep them visible
// Breaks near-ties toward project scripts without burying engine components:
// "sprite" still gives cc.Sprite first, "spr" gives SpriteDecorate first.
const PROJECT_BONUS = 10;
const STATUS_REVERT_MS = 2500;

/**
 * Component colour buckets. Three real kinds plus one error state - enough to tell
 * "my code" from "engine drawing" from "engine behaviour" at a glance without
 * turning the bar into a rainbow. Classification happens in scene-script.js.
 */
const COMPONENT_KINDS = {
  script: 'project script',
  render: 'engine renderer',
  engine: 'engine component',
  missing: 'MISSING SCRIPT',
};

/** "cc.Sprite" -> "Sprite". Engine prefixes waste room in the one-line context bar. */
function shortenClassName (name) {
  const dot = name.lastIndexOf('.');
  return dot >= 0 ? name.slice(dot + 1) : name;
}

// Subsequence scoring weights. Tuned so that camelCase word starts outrank
// mid-word substrings: "ge" must put GradientMask above SlicedImageMask.
const SCORE_EXACT = 100000;
const SCORE_CHAR = 16;         // every matched character
const SCORE_BOUNDARY = 18;     // match lands on a camelCase / separator word start
const SCORE_FIRST = 10;        // extra when it lands on index 0
const SCORE_CONSECUTIVE = 15;  // match directly follows the previous one
const PENALTY_GAP = 4;         // match does not follow the previous one
const PENALTY_LEADING = 0.6;   // per character before the first match
const PENALTY_LENGTH = 0.3;    // per character of the candidate name
const NEG = -1e9;

function range (from, to) {
  const out = [];
  for (let i = from; i < to; ++i) {
    out.push(i);
  }
  return out;
}

function isUpper (ch) {
  return ch >= 'A' && ch <= 'Z';
}

function isDigit (ch) {
  return ch >= '0' && ch <= '9';
}

/** Mark indexes that start a word: index 0, a camelCase hump, a digit run, or after a separator. */
function computeBoundaries (name) {
  const flags = new Array(name.length);
  for (let j = 0; j < name.length; ++j) {
    const ch = name[j];
    const prev = j > 0 ? name[j - 1] : '';
    flags[j] = j === 0
      || (isUpper(ch) && !isUpper(prev))
      || (isDigit(ch) && !isDigit(prev))
      || prev === '_' || prev === '.' || prev === '/';
  }
  return flags;
}

/**
 * Score a candidate against the query with a fuzzy subsequence match.
 * Returns { score, hits } where hits are the matched character indexes used for
 * highlighting, or null when the candidate does not match. Higher score wins.
 */
function scoreCandidate (name, query) {
  const n = name.length;
  const m = query.length;
  if (m === 0) {
    return { score: 0, hits: [] };
  }
  if (m > n) {
    return null;
  }

  const lowerName = name.toLowerCase();
  const lowerQuery = query.toLowerCase();
  if (lowerName === lowerQuery) {
    return { score: SCORE_EXACT, hits: range(0, n) };
  }

  const boundary = computeBoundaries(name);
  const rows = [];
  const backs = [];
  let prevRow = null;

  for (let i = 0; i < m; ++i) {
    const row = new Array(n).fill(NEG);
    const back = new Array(n).fill(-1);
    let bestPrev = NEG;
    let bestPrevIndex = -1;

    for (let j = 0; j < n; ++j) {
      // running best of the previous row over all k <= j-1
      if (i > 0 && j > 0 && prevRow[j - 1] > bestPrev) {
        bestPrev = prevRow[j - 1];
        bestPrevIndex = j - 1;
      }
      if (lowerQuery[i] !== lowerName[j]) {
        continue;
      }

      const charScore = SCORE_CHAR
        + (boundary[j] ? SCORE_BOUNDARY : 0)
        + (j === 0 ? SCORE_FIRST : 0);

      if (i === 0) {
        row[j] = charScore - PENALTY_LEADING * j;
        continue;
      }

      let best = NEG;
      let bestFrom = -1;
      if (j > 0 && prevRow[j - 1] > NEG / 2) {
        best = prevRow[j - 1] + charScore + SCORE_CONSECUTIVE;
        bestFrom = j - 1;
      }
      if (bestPrev > NEG / 2) {
        const gapped = bestPrev + charScore - PENALTY_GAP;
        if (gapped > best) {
          best = gapped;
          bestFrom = bestPrevIndex;
        }
      }
      if (best <= NEG / 2) {
        continue;
      }
      row[j] = best;
      back[j] = bestFrom;
    }

    rows.push(row);
    backs.push(back);
    prevRow = row;
  }

  const lastRow = rows[m - 1];
  let bestScore = NEG;
  let bestIndex = -1;
  for (let j = 0; j < n; ++j) {
    if (lastRow[j] > bestScore) {
      bestScore = lastRow[j];
      bestIndex = j;
    }
  }
  if (bestIndex < 0 || bestScore <= NEG / 2) {
    return null;
  }

  const hits = new Array(m);
  let cursor = bestIndex;
  for (let i = m - 1; i >= 0; --i) {
    hits[i] = cursor;
    cursor = backs[i][cursor];
  }

  return { score: bestScore - PENALTY_LENGTH * n, hits: hits };
}

Editor.Panel.extend({
  style: `
    :host {
      display: flex;
      flex-direction: column;
      margin: 0;
      height: 100%;
      font-size: 12px;
    }
    .search-bar { padding: 6px; border-bottom: 1px solid #2b2b2b; }
    .search-bar input {
      width: 100%;
      box-sizing: border-box;
      padding: 6px 8px;
      font-size: 13px;
      border: 1px solid #3c3c3c;
      border-radius: 3px;
      background: #22252a;
      color: #ddd;
      outline: none;
    }
    .search-bar input:focus { border-color: #f90; }
    /* Node name + its components. Wraps, but hard-clamped to two lines. */
    .status {
      display: -webkit-box;
      -webkit-line-clamp: 2;
      -webkit-box-orient: vertical;
      overflow: hidden;
      padding: 3px 8px;
      line-height: 1.45;
      color: #888;
      border-bottom: 1px solid #2b2b2b;
    }
    .status.warn { color: #d88; }
    .status .node { color: #dcdcdc; font-weight: 600; }
    .status .node.none { color: #a66; font-weight: normal; }
    .status .sep { color: #4a4a4a; }
    .status em { color: #6f6f6f; font-style: normal; }

    /* Component kinds - four colors, see COMPONENT_KINDS */
    .kind-script  { color: #e0a44a; }
    .kind-render  { color: #5fa8d3; }
    .kind-engine  { color: #7bb972; }
    .kind-missing { color: #d9534f; font-weight: 600; }
    .list { flex: 1; overflow-y: auto; }
    .item {
      display: flex;
      align-items: baseline;
      gap: 8px;
      padding: 5px 8px;
      cursor: pointer;
      border-left: 2px solid transparent;
    }
    .item:hover { background: #2c3038; }
    .item.active { background: #38414f; border-left-color: #f90; }
    /* Colour comes from the .kind-* class; do not set it here or it wins on specificity. */
    .item .name { flex: none; }
    .item.present .name { font-weight: 700; }
    .item.blocked { opacity: 0.55; }
    .item .name b { color: #fff; font-weight: 700; }
    .item .path {
      color: #777;
      flex: 1;
      text-align: right;
      overflow: hidden;
      text-overflow: ellipsis;
      white-space: nowrap;
      direction: rtl;
    }
    .item .badge {
      flex: none;
      color: #6a8;
      font-size: 10px;
    }
    .item .badge.on-node { color: #888; }
    .empty { padding: 12px 8px; color: #777; line-height: 1.6; }
    .empty .key {
      background: #333;
      border: 1px solid #444;
      border-radius: 3px;
      padding: 0 4px;
      color: #aaa;
    }
    .section {
      padding: 3px 8px;
      color: #666;
      font-size: 10px;
      text-transform: uppercase;
      letter-spacing: 0.5px;
      background: #202226;
    }
    .footer {
      padding: 4px 8px;
      border-top: 1px solid #2b2b2b;
      color: #666;
      display: flex;
      justify-content: space-between;
      align-items: center;
      gap: 8px;
    }
    .footer a { color: #789; cursor: pointer; text-decoration: underline; }
  `,

  template: `
    <div class="search-bar">
      <input id="query" type="text" placeholder="Search component... (Enter to add, Esc to clear)" />
    </div>
    <div class="status" id="status">-</div>
    <div class="list" id="list"></div>
    <div class="footer">
      <span>&uarr;&darr; move &middot; Enter add &middot; Esc clear</span>
      <span><span id="count">0</span> &middot; <a id="refresh">refresh</a> &middot; <a id="probe">probe</a></span>
    </div>
  `,

  $: {
    query: '#query',
    status: '#status',
    list: '#list',
    count: '#count',
    refresh: '#refresh',
    probe: '#probe',
  },

  ready () {
    this._all = [];
    this._filtered = [];
    this._activeIndex = 0;
    this._recent = [];
    this._paths = {};
    this._present = new Set();
    this._blockedGroupsAll = new Set();
    this._blockedGroupsAny = new Set();
    this._occupiedBy = {};
    this._context = { names: [], present: [] };
    this._statusTimer = null;

    this.$query.addEventListener('input', () => this._refilter());
    this.$query.addEventListener('keydown', (event) => this._onKeyDown(event));
    this.$refresh.addEventListener('click', () => this._loadComponents());
    this.$probe.addEventListener('click', () => this._probe());

    this._loadRecent();
    this._loadComponents();
    this._syncSelection();
    this.$query.focus();
  },

  // ---------------------------------------------------------------- recent

  _loadRecent () {
    Editor.Ipc.sendToMain('component-search:load-recent', (err, recent) => {
      if (err) {
        return;
      }
      this._recent = recent || [];
      this._refilter();
    });
  },

  _saveRecent () {
    Editor.Ipc.sendToMain('component-search:save-recent', this._recent);
  },

  // ---------------------------------------------------------------- data

  _callScene (method, args, done) {
    if (!Editor.Scene || typeof Editor.Scene.callSceneScript !== 'function') {
      this._setStatus('Editor.Scene.callSceneScript unavailable', true);
      return;
    }
    const cb = (err, data) => {
      if (err) {
        this._setStatus('scene-script "' + method + '": ' + err, true);
        return;
      }
      done(data);
    };
    if (args === undefined) {
      Editor.Scene.callSceneScript('component-search', method, cb);
    } else {
      Editor.Scene.callSceneScript('component-search', method, args, cb);
    }
  },

  _loadComponents () {
    this._callScene('list-components', undefined, (list) => {
      this._all = list || [];
      this.$count.textContent = this._all.length;
      this._resolvePaths();
      this._refilter();
    });
  },

  /**
   * Refresh which components already sit on the current selection, then repaint.
   * Pass keepStatus when the caller already wrote a message worth keeping.
   */
  _syncSelection (keepStatus) {
    const selection = this._currentSelection();
    if (!selection.length) {
      this._present = new Set();
      this._blockedGroupsAll = new Set();
      this._blockedGroupsAny = new Set();
      this._occupiedBy = {};
      this._context = { names: [], present: [] };
      if (!keepStatus) {
        this._renderContext();
      }
      this._refilter();
      return;
    }
    this._callScene('node-components', { nodeUuids: selection }, (data) => {
      const present = (data && data.present) || [];
      this._present = new Set(present.map(c => c.name));
      this._blockedGroupsAll = new Set((data && data.blockedGroupsAll) || []);
      this._blockedGroupsAny = new Set((data && data.blockedGroupsAny) || []);
      this._occupiedBy = (data && data.occupiedBy) || {};
      this._context = {
        names: (data && data.names) || [],
        present: present,
      };
      if (!keepStatus) {
        this._renderContext();
      }
      this._refilter();
    });
  },

  _resolvePaths () {
    const uuids = this._all.map(c => c.scriptUuid).filter(Boolean);
    if (!uuids.length) {
      return;
    }
    Editor.Ipc.sendToMain('component-search:resolve-paths', uuids, (err, map) => {
      if (err) {
        return;
      }
      this._paths = map || {};
      this._render();
    });
  },

  // ---------------------------------------------------------------- filter

  _refilter () {
    const query = this.$query.value.trim();

    // Empty query is a launcher, not a catalogue: show only what the user
    // actually reaches for. Browsing 170+ components in a flat list helps nobody.
    if (!query) {
      this._filtered = this._recent
        .map(name => this._all.find(c => c.className === name))
        .filter(Boolean)
        .map(c => ({ item: c, hits: [], recent: true }));
      this._activeIndex = 0;
      this._render();
      return;
    }

    const scored = [];
    for (let i = 0; i < this._all.length; ++i) {
      const item = this._all[i];
      // Score against the short name so "sprite" ranks cc.Sprite properly.
      const result = scoreCandidate(item.displayName, query);
      if (!result) {
        continue;
      }
      let score = result.score;
      if (item.isProject) {
        score += PROJECT_BONUS;
      }
      if (this._recent.indexOf(item.className) >= 0) {
        score += RECENT_BONUS;
      }
      // Sink anything the node already has, and anything conflicting with what it has.
      if (this._present.has(item.className)
          || (item.exclusiveGroup && this._blockedGroupsAny.has(item.exclusiveGroup))) {
        score -= PRESENT_PENALTY;
      }
      scored.push({ item: item, hits: result.hits, score: score });
    }
    scored.sort((a, b) => b.score - a.score || a.item.displayName.localeCompare(b.item.displayName));
    this._filtered = scored.slice(0, MAX_RESULTS);

    this._activeIndex = 0;
    this._render();
  },

  // ---------------------------------------------------------------- render

  _render () {
    const list = this.$list;
    list.textContent = '';

    if (!this._filtered.length) {
      list.appendChild(this._buildEmptyState());
      return;
    }

    if (!this.$query.value.trim()) {
      const section = document.createElement('div');
      section.className = 'section';
      section.textContent = 'recently used';
      list.appendChild(section);
    }

    this._filtered.forEach((entry, index) => {
      const className = entry.item.className;
      const isPresent = this._present.has(className);
      const conflict = this._conflictFor(entry.item);
      const isBlocked = !!conflict;

      const row = document.createElement('div');
      row.className = 'item'
        + (index === this._activeIndex ? ' active' : '')
        + (isPresent ? ' present' : '')
        + (isBlocked ? ' blocked' : '');

      const name = document.createElement('span');
      name.className = 'name kind-' + (COMPONENT_KINDS[entry.item.kind] ? entry.item.kind : 'engine');
      name.title = className + '  (' + (COMPONENT_KINDS[entry.item.kind] || 'engine component') + ')';
      this._appendHighlighted(name, entry.item.displayName, entry.hits);
      row.appendChild(name);

      if (isBlocked && !isPresent) {
        // Not on the node itself, but something sharing its exclusive base is.
        const badge = document.createElement('span');
        badge.className = 'badge on-node';
        badge.textContent = 'conflicts with ' + shortenClassName(conflict);
        row.appendChild(badge);
      } else if (isPresent) {
        const badge = document.createElement('span');
        badge.className = 'badge on-node';
        badge.textContent = isBlocked ? 'on node (single only)' : 'on node';
        row.appendChild(badge);
      } else if (entry.recent) {
        const badge = document.createElement('span');
        badge.className = 'badge';
        badge.textContent = 'recent';
        row.appendChild(badge);
      }

      const path = document.createElement('span');
      path.className = 'path';
      path.textContent = this._describe(entry.item);
      row.appendChild(path);

      row.addEventListener('click', () => {
        this._activeIndex = index;
        this._addActive();
      });

      list.appendChild(row);
    });

    this._scrollActiveIntoView();
  },

  _buildEmptyState () {
    const empty = document.createElement('div');
    empty.className = 'empty';

    if (!this._all.length) {
      empty.textContent = 'no components loaded - press refresh';
      return empty;
    }

    if (this.$query.value.trim()) {
      empty.textContent = 'no match for "' + this.$query.value.trim() + '"';
      return empty;
    }

    const projectCount = this._all.filter(c => c.isProject).length;
    empty.appendChild(document.createTextNode(
      'Type to search ' + projectCount + ' scripts + ' + (this._all.length - projectCount) + ' engine components.'));
    empty.appendChild(document.createElement('br'));

    const hint = document.createElement('span');
    hint.textContent = 'Initials work too - ';
    empty.appendChild(hint);

    const key = document.createElement('span');
    key.className = 'key';
    key.textContent = 'sv';
    empty.appendChild(key);

    empty.appendChild(document.createTextNode(' finds ScrollView.'));
    empty.appendChild(document.createElement('br'));
    empty.appendChild(document.createTextNode('Components you add show up here next time.'));
    return empty;
  },

  _appendHighlighted (host, text, hits) {
    const hitSet = new Set(hits);
    let buffer = '';
    let bufferHit = false;

    const flush = () => {
      if (!buffer) {
        return;
      }
      if (bufferHit) {
        const b = document.createElement('b');
        b.textContent = buffer;
        host.appendChild(b);
      } else {
        host.appendChild(document.createTextNode(buffer));
      }
      buffer = '';
    };

    for (let i = 0; i < text.length; ++i) {
      const isHit = hitSet.has(i);
      if (isHit !== bufferHit) {
        flush();
        bufferHit = isHit;
      }
      buffer += text[i];
    }
    flush();
  },

  _describe (item) {
    if (item.menuPath) {
      return item.menuPath;
    }
    const url = this._paths[item.scriptUuid];
    if (url) {
      return url.replace(/^db:\/\/assets\//, '');
    }
    return '';
  },

  _scrollActiveIntoView () {
    const active = this.$list.querySelector('.item.active');
    if (!active) {
      return;
    }
    const listTop = this.$list.scrollTop;
    const listBottom = listTop + this.$list.clientHeight;
    if (active.offsetTop < listTop) {
      this.$list.scrollTop = active.offsetTop;
    } else if (active.offsetTop + active.offsetHeight > listBottom) {
      this.$list.scrollTop = active.offsetTop + active.offsetHeight - this.$list.clientHeight;
    }
  },

  // ---------------------------------------------------------------- input

  _onKeyDown (event) {
    switch (event.keyCode) {
      case 38: // up
        event.preventDefault();
        this._move(-1);
        break;
      case 40: // down
        event.preventDefault();
        this._move(1);
        break;
      case 13: // enter
        event.preventDefault();
        this._addActive();
        break;
      case 27: // esc
        event.preventDefault();
        if (this.$query.value) {
          this.$query.value = '';
          this._refilter();
        }
        break;
      default:
        break;
    }
  },

  _move (delta) {
    if (!this._filtered.length) {
      return;
    }
    this._activeIndex = (this._activeIndex + delta + this._filtered.length) % this._filtered.length;
    this._render();
  },

  // ---------------------------------------------------------------- action

  /**
   * The component blocking this candidate, or '' when it can be added.
   * Only hard-blocks when every selected node is blocked - with a mixed selection
   * the add still helps the nodes that can take it, and per-node failures are reported.
   */
  _conflictFor (item) {
    const group = item.exclusiveGroup;
    if (!group || !this._blockedGroupsAll.has(group)) {
      return '';
    }
    return this._occupiedBy[group] || group;
  },

  _currentSelection () {
    if (!Editor.Selection || typeof Editor.Selection.curSelection !== 'function') {
      return [];
    }
    return Editor.Selection.curSelection('node') || [];
  },

  _addActive () {
    const entry = this._filtered[this._activeIndex];
    if (!entry) {
      return;
    }

    const selection = this._currentSelection();
    if (!selection.length) {
      this._setStatus('select a node first', true);
      return;
    }

    const className = entry.item.className;
    const conflict = this._conflictFor(entry.item);
    if (conflict) {
      this._setStatus(
        conflict === className
          ? className + ' is already on the node and allows only one'
          : className + ' conflicts with ' + shortenClassName(conflict) + ' already on the node',
        true);
      return;
    }

    this._callScene('add-component', { nodeUuids: selection, className: className }, (result) => {
      if (!result) {
        return;
      }
      this._pushRecent(className);

      let message = 'added ' + className + ' to ' + result.added + ' node(s)';
      if (result.failed && result.failed.length) {
        message += ' - ' + result.failed.length + ' failed: ' + result.failed[0].reason;
        this._setStatus(message, true);
      } else {
        this._setStatus(message + ' [undo: ' + result.undoStrategy + ' / dirty: ' + result.dirtyStrategy + ']');
      }

      this.$query.value = '';
      this._syncSelection(true);
      this.$query.focus();
    });
  },

  _pushRecent (className) {
    this._recent = [className].concat(this._recent.filter(n => n !== className)).slice(0, RECENT_LIMIT);
    this._saveRecent();
  },

  _probe () {
    this._callScene('probe', undefined, (data) => {
      Editor.log('[component-search] probe: ' + JSON.stringify(data, null, 2));
      this._setStatus('probe result printed to Console');
    });
  },

  // ---------------------------------------------------------------- status

  /** Transient message. Reverts to the context line so the bar never grows. */
  _setStatus (text, isWarn) {
    if (this._statusTimer) {
      clearTimeout(this._statusTimer);
    }
    this.$status.textContent = text;
    this.$status.className = isWarn ? 'status warn' : 'status';
    this._statusTimer = setTimeout(() => {
      this._statusTimer = null;
      this._renderContext();
    }, STATUS_REVERT_MS);
  },

  /**
   * One line: selected node name + the components already on it.
   * Both halves ellipsis on overflow, so the bar stays exactly one row tall.
   */
  _renderContext () {
    if (this._statusTimer) {
      return; // a transient message owns the bar right now
    }

    const bar = this.$status;
    bar.className = 'status';
    bar.textContent = '';

    const nodeSpan = document.createElement('span');
    nodeSpan.className = 'node';
    const names = this._context.names;

    if (!names.length) {
      nodeSpan.className = 'node none';
      nodeSpan.textContent = 'no node selected';
      bar.appendChild(nodeSpan);
      return;
    }

    nodeSpan.textContent = names.length === 1 ? names[0] : names.length + ' nodes';
    nodeSpan.title = names.join(', ');
    bar.appendChild(nodeSpan);

    const comps = this._context.present;
    if (!comps.length) {
      bar.appendChild(document.createTextNode(' '));
      const em = document.createElement('em');
      em.textContent = 'no components';
      bar.appendChild(em);
      return;
    }

    comps.forEach((comp, index) => {
      const sep = document.createElement('span');
      sep.className = 'sep';
      sep.textContent = index === 0 ? '  ' : ' · ';
      bar.appendChild(sep);

      const chip = document.createElement('span');
      chip.className = 'kind-' + (COMPONENT_KINDS[comp.kind] ? comp.kind : 'engine');
      chip.textContent = shortenClassName(comp.name);
      chip.title = comp.name + '  (' + (COMPONENT_KINDS[comp.kind] || 'engine component') + ')';
      bar.appendChild(chip);
    });
  },

  messages: {
    'selection:selected' () {
      this._syncSelection();
    },
    'selection:unselected' () {
      this._syncSelection();
    },
    'selection:activated' () {
      this._syncSelection();
    },
    'scene:ready' () {
      this._loadComponents();
    },
    'component-search:focus' () {
      this.$query.focus();
      this.$query.select();
    },
  },
});
