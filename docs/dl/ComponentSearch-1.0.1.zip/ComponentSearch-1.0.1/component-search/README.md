# Component Search

Cocos Creator **2.4** 에디터 확장. 노드를 고르고 단축키를 누르면 검색창이 뜨고,
컴포넌트 이름을 타이핑해서 바로 붙일 수 있습니다.

Creator 3.x가 기본 제공하는 Add Component 검색 박스를 2.4로 백포트한 것입니다.
(2.4는 중첩 메뉴만 있고 검색이 없습니다.)

```
노드 선택 → Cmd+Shift+A → "sv" → ScrollView → Enter
```

---

## 설치

### 방법 0 — 더블클릭 (가장 쉬움, 전역 설치)

| OS | 파일 |
|---|---|
| macOS | `install.command` |
| Windows | `install.bat` |

Finder/탐색기에서 더블클릭하면 `~/.CocosCreator/packages/` 로 설치됩니다.

> macOS에서 "확인되지 않은 개발자" 경고가 뜨면 파일 우클릭 → **열기** 를 한 번 선택하거나,
> 터미널에서 `xattr -d com.apple.quarantine install.command` 를 실행하세요.
> (인터넷으로 받은 파일에 붙는 격리 속성 때문이며, 사내 공유라면 안 뜰 수도 있습니다.)

### 방법 A — 전역 (모든 프로젝트에서 사용)

```bash
./install.sh --global
```

`~/.CocosCreator/packages/component-search/` 로 복사합니다.

### 방법 B — 프로젝트 (git으로 팀 공유)

```bash
./install.sh --project /path/to/your-project
```

`<프로젝트>/packages/component-search/` 로 복사합니다.
이 방식은 저장소에 커밋되므로 팀원이 따로 설치할 필요가 없습니다.

### 방법 C — 수동

이 폴더를 통째로 위 두 경로 중 하나에 복사합니다.

**설치 후 Cocos Creator를 재시작하세요.** 콘솔에 `[component-search] package loaded` 가 뜨면 성공입니다.

---

## 이 폴더는 소스입니다 (설치본이 아님)

`tools/component-search/` 는 **버전 관리용 소스**이고, 실제로 에디터가 읽는 것은
`~/.CocosCreator/packages/component-search/` 에 설치된 사본입니다.

- Cocos는 `assets/` 와 `packages/` 만 스캔하므로 `tools/` 에 있는 이 폴더는 에디터가 무시합니다
- **코드를 고쳤으면 반드시 `./install.sh --global` 로 재설치**해야 반영됩니다
- 배포용 zip 생성: `./install.sh --pack`

---

## 사용법

| 키 | 동작 |
|---|---|
| `Cmd/Ctrl + Shift + A` | 패널 열기 + 입력창 포커스 |
| `↑` `↓` | 결과 이동 |
| `Enter` | 선택한 노드(들)에 추가 |
| `Esc` | 검색어 지우기 |

- **fuzzy 검색** — `sv` → `ScrollView`, `pes` → `PopupEventShadowChase`
- **최근 사용** — 검색어가 비면 최근 쓴 8개를 보여줍니다. 에디터를 껐다 켜도 유지됩니다
- **다중 선택** — 노드 여러 개를 고르면 한 번에 추가됩니다
- **컨텍스트 바** — 선택한 노드 이름과 이미 붙어 있는 컴포넌트를 보여줍니다

### 색상 구분

| 색 | 의미 |
|---|---|
| 🟠 앰버 | 프로젝트 스크립트 |
| 🔵 블루 | 엔진 렌더러 (Sprite, Label, Mask …) |
| 🟢 그린 | 그 외 엔진 컴포넌트 (Button, Widget, Layout …) |
| 🔴 레드 | Missing Script (깨진 참조) |

### 충돌 표시

`cc.RenderComponent` 를 상속한 컴포넌트는 노드당 하나만 붙습니다.
이미 `Mask` 가 있는 노드에서 `Sprite` 를 고르면 `conflicts with Mask` 로 표시되고 추가가 막힙니다.
엔진 에러를 띄우는 대신 미리 걸러냅니다.

---

## 동작 원리

- 컴포넌트 목록은 런타임에 `cc._componentMenuItems` 에서 읽습니다. 내장 Add Component 버튼이
  쓰는 것과 같은 소스라 범위가 동일하고, **어느 프로젝트에 넣든 그 프로젝트 스크립트를 자동으로 잡습니다**
- 프로젝트 스크립트 판별은 `cls.prototype.__scriptUuid` (사용자 스크립트에만 존재)
- 추가는 엔진 정규 경로인 `node.addComponent()` 를 그대로 호출하므로, 저장되는 프리팹/씬 데이터가
  내장 버튼으로 붙인 것과 **완전히 동일**합니다

## 빌드 영향

**없습니다.** 에디터 확장은 `assets/` 밖에 있어 asset-db가 임포트하지 않고,
빌드 산출물에 한 바이트도 들어가지 않습니다.

---

## 제약

- **내장 Add Component 버튼은 그대로 남습니다.** 2.4의 인스펙터 구현이 암호화(`.ccc`)되어 있고
  `app.asar` 안에 패킹되어 있어 그 버튼 자체를 검색형으로 교체할 수 없습니다. 진입점이 둘이 됩니다
- `project.json` 에서 제외한 모듈(Physics, Collider, 3D, Spine 등)의 컴포넌트는 엔진에 등록되지
  않으므로 검색에도 안 나옵니다 (정상 동작)
- `cc.Node` 는 컴포넌트가 아니라 검색 대상이 아닙니다
- Creator **3.x 미지원** — 3.x는 이 기능이 기본 탑재입니다

## Undo

`Cmd/Ctrl + Z` 로 되돌아갑니다. Creator 2.4.10 실기 확인 완료.

## 알려진 미검증 항목

- **최근 사용 영속성** — `Editor.Profile` 의 `local://` 스킴. 실패해도 인메모리로 폴백하므로
  최악의 경우 에디터를 껐다 켜면 최근 목록만 비어 있습니다. 기능에는 영향 없습니다

## 라이선스

MIT
