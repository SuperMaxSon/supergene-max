'use strict';

const PROFILE_URL = 'local://component-search.json';

/**
 * Editor.Profile only exists in the main process.
 * API shape confirmed from the editor's own i18n bootstrap:
 *   Editor.Profile.load(url) -> { get(key), set(key, value), save() }
 */
function loadProfile () {
  if (!Editor.Profile || typeof Editor.Profile.load !== 'function') {
    return null;
  }
  try {
    return Editor.Profile.load(PROFILE_URL);
  } catch (err) {
    Editor.warn('[component-search] profile unavailable: ' + err.message);
    return null;
  }
}

module.exports = {
  load () {
    Editor.log('[component-search] package loaded');
  },

  unload () {
  },

  messages: {
    'open' () {
      Editor.Panel.open('component-search');
      // If the panel was already open, ready() will not run again - focus the input.
      Editor.Ipc.sendToPanel('component-search', 'component-search:focus');
    },

    /**
     * Resolve script asset uuids to db:// urls.
     * assetdb only lives in the main process, so the panel asks for it here.
     */
    'resolve-paths' (event, uuids) {
      const result = {};
      if (Array.isArray(uuids)) {
        for (let i = 0; i < uuids.length; ++i) {
          const uuid = uuids[i];
          if (!uuid) {
            continue;
          }
          try {
            const url = Editor.assetdb.uuidToUrl(uuid);
            if (url) {
              result[uuid] = url;
            }
          } catch (err) {
            // asset removed or db not ready - leave it unresolved
          }
        }
      }
      if (event && typeof event.reply === 'function') {
        event.reply(null, result);
      }
    },

    'load-recent' (event) {
      const profile = loadProfile();
      const recent = profile ? profile.get('recent') : null;
      if (event && typeof event.reply === 'function') {
        event.reply(null, Array.isArray(recent) ? recent : []);
      }
    },

    'save-recent' (event, recent) {
      const profile = loadProfile();
      if (profile) {
        profile.set('recent', Array.isArray(recent) ? recent : []);
        profile.save();
      }
      if (event && typeof event.reply === 'function') {
        event.reply(null, true);
      }
    },
  },
};
