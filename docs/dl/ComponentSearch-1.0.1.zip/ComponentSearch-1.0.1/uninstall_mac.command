#!/usr/bin/env bash
# Component Search - Cocos Creator 2.4 확장 삭제 프로그램 (macOS)
# 이 파일을 더블클릭하면 설치된 확장을 제거합니다.

cd "$(dirname "$0")" || exit 1

PKG_NAME="component-search"
DEST_DIR="$HOME/.CocosCreator/packages"
DEST="$DEST_DIR/$PKG_NAME"
BACKUP="$DEST.bak"

# 터미널 기본 설정이 "쉘 종료 시 창 유지"라 스크립트가 끝나도 창은 남는다.
# 자동으로 닫으려면 터미널 자동화 권한 승인 창이 뜨는데, 배포용으로는 그게 더 번거로워서
# 문구로만 안내한다.
finish () {
  echo
  if [ -t 0 ]; then
    read -n 1 -r -p "확인했으면 아무 키나 누르세요. (이 창은 Cmd + W 로 닫으시면 됩니다)"
    echo
  fi
  exit "${1:-0}"
}

echo "Component Search - 삭제  (제작: Max)"
echo

targets=()
[ -e "$DEST" ] && targets+=("$DEST")
[ -e "$BACKUP" ] && targets+=("$BACKUP")

if [ ${#targets[@]} -eq 0 ]; then
  echo "설치되어 있지 않습니다. 지울 것이 없습니다."
  echo "확인한 위치: $DEST"
  finish 0
fi

echo "아래 폴더를 지웁니다."
for t in "${targets[@]}"; do
  echo "  - $t"
done
echo

if [ -t 0 ]; then
  printf '정말 지울까요? [y/N] '
  read -r answer
else
  answer="n"
fi

case "$answer" in
  y|Y) ;;
  *) echo "취소했습니다. 아무것도 지우지 않았습니다."; finish 1 ;;
esac

for t in "${targets[@]}"; do
  rm -rf "$t" || { echo "삭제에 실패했습니다: $t"; finish 1; }
  echo "삭제됨 -> $t"
done

echo
echo "Cocos Creator 를 완전히 종료했다가 다시 실행하면 확장이 사라집니다."
echo "다시 설치하려면 같은 폴더의 'install_mac.command' 를 실행하세요."
finish 0
