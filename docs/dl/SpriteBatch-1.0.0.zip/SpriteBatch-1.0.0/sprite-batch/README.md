# Sprite Batch

Unity-style multi-object editing for image assets in Cocos Creator 2.4.
Select many images (or a folder) in the Assets panel, press `Shift+Cmd+S`, change the
fields you care about, hit Apply.

## Why

2.4's Inspector shows a single image at a time. Flipping `packable` or `trimType` on a
few hundred sprites means opening them one by one. 3.x has no batch editor either.

## Rules it follows

- **Only touched fields are written.** Everything else keeps each asset's own value.
- **Disagreeing values render as `-` (mixed)** and stay out of the write until you pick one.
- **No-op writes are skipped**, so re-applying the same value costs zero reimports.
- **Writes go through `Editor.assetdb.saveMeta` + `refresh`**, never direct `.meta` edits -
  the editor caches meta in memory and recomputes derived fields on import. Writing the
  file directly is a last resort used only when `saveMeta` does not exist at all.
- `trimType: none` also resets the derived rect (`trimX/trimY/offsetX/offsetY/width/height`)
  to the full image; `auto`/`custom` are left to the importer.

## Fields

| Level | Fields |
|---|---|
| Texture | `type`, `wrapMode`, `filterMode`, `premultiplyAlpha`, `genMipmaps`, `packable` |
| Sprite frame (all subMetas) | `trimType`, `trimThreshold` |
| Compression | `platformSettings` - copy from another asset, clear, or paste verbatim JSON |

Deliberately excluded: 9-slice borders, trim rect, width/height - per-asset values a batch
edit would destroy.

## Notes

- Reads fall back to the `.meta` on disk when an assetdb helper is missing, so the panel
  works across 2.4.x builds; `probe` in the footer prints what it actually found.
- IPC replies are sent with no timeout: a few hundred reimports blow past the 5s default.
- Changing `type` drops sprite-frame subMetas and breaks prefabs referencing them - the
  panel warns before Apply.

## Files

- `main.js` - assetdb reads/writes, folder expansion, sequential apply with progress, probe.
- `panel/index.js` - aggregation (common/mixed), dirty tracking, apply UI.

---

Made by Max.
