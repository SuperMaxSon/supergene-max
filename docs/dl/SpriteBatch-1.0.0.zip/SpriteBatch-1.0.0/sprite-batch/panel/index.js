'use strict';

/**
 * Sprite Batch - panel (renderer side).
 *
 * Unity-style multi-object editing for image assets:
 *   - the panel follows the Assets selection,
 *   - fields whose values disagree across the selection render as "-" (mixed),
 *   - ONLY the fields you actually touch are written; everything else keeps each
 *     asset's own value. Without that rule a mixed field would be flattened by accident.
 *
 * All assetdb work happens in main.js; this file just aggregates and renders.
 */

const MIXED = '__mixed__';
const NO_CHANGE = '__nochange__';
const CONFIRM_ABOVE = 50;   // batches this large ask for a second click
const IPC_NO_TIMEOUT = -1;  // Ipc defaults to a 5s reply timeout - a few hundred reimports blow past it
const STATUS_REVERT_MS = 4000;

const FIELDS = [
  { key: 'type', level: 'texture', label: 'Type', kind: 'select', options: ['raw', 'texture', 'sprite'] },
  { key: 'wrapMode', level: 'texture', label: 'Wrap Mode', kind: 'select', options: ['clamp', 'repeat'] },
  { key: 'filterMode', level: 'texture', label: 'Filter Mode', kind: 'select', options: ['point', 'bilinear', 'trilinear'] },
  { key: 'premultiplyAlpha', level: 'texture', label: 'Premultiply Alpha', kind: 'bool' },
  { key: 'genMipmaps', level: 'texture', label: 'Gen Mipmaps', kind: 'bool' },
  { key: 'packable', level: 'texture', label: 'Packable', kind: 'bool' },
  { key: 'trimType', level: 'sprite', label: 'Trim Type', kind: 'select', options: ['auto', 'custom', 'none'] },
  { key: 'trimThreshold', level: 'sprite', label: 'Trim Threshold', kind: 'number' },
];

function boolLabel (value) {
  return value ? 'true' : 'false';
}

function shortJson (text) {
  if (text === '{}') {
    return '{}  (none)';
  }
  return text.length > 64 ? text.slice(0, 61) + '...' : text;
}

Editor.Panel.extend({
  style: `
    :host { display: flex; flex-direction: column; margin: 0; height: 100%; font-size: 12px; color: #ccc; }

    .head {
      display: flex; align-items: center; justify-content: space-between; gap: 8px;
      padding: 6px 8px; border-bottom: 1px solid #2b2b2b; background: #202226;
    }
    .head .summary { overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
    .head .summary b { color: #fff; }
    .head .summary.none { color: #a66; }
    .head a { color: #789; cursor: pointer; text-decoration: underline; flex: none; }

    .body { flex: 1; overflow-y: auto; }

    .section {
      padding: 4px 8px; color: #666; font-size: 10px; text-transform: uppercase;
      letter-spacing: 0.5px; background: #202226; border-top: 1px solid #2b2b2b;
    }

    .row {
      display: flex; align-items: center; gap: 8px;
      padding: 4px 8px; border-left: 2px solid transparent;
    }
    .row.dirty { background: #332d22; border-left-color: #f90; }
    .row label { flex: none; width: 132px; color: #aaa; }
    .row.dirty label { color: #ffb64d; font-weight: 600; }
    .row select, .row input {
      flex: 1; min-width: 0; padding: 3px 5px; font-size: 12px;
      background: #22252a; color: #ddd; border: 1px solid #3c3c3c; border-radius: 3px; outline: none;
    }
    .row select:focus, .row input:focus { border-color: #f90; }
    /* A staged edit has to read as staged at a glance - border, text and fill all move. */
    .row.dirty select, .row.dirty input {
      border-color: #f90; color: #ffcf80; background: #2b2620; font-weight: 600;
    }
    .row .was {
      flex: none; max-width: 104px; overflow: hidden; text-overflow: ellipsis; white-space: nowrap;
      color: #7a7266; font-size: 11px;
    }
    .row .revert { flex: none; width: 14px; text-align: center; color: #888; cursor: pointer; }
    .row .revert:hover { color: #f90; }
    .row .revert.hidden { visibility: hidden; }
    .section .badge { color: #f90; }

    .plat { padding: 6px 8px; }
    .plat .current { color: #999; margin-bottom: 6px; word-break: break-all; }
    .plat .current b { color: #ddd; }
    .plat .current.mixed b { color: #e0a44a; }
    .plat .pending { color: #f90; margin-bottom: 6px; word-break: break-all; }
    .plat .controls { display: flex; gap: 6px; align-items: center; flex-wrap: wrap; }
    .plat select, .plat button {
      padding: 3px 6px; font-size: 11px; background: #22252a; color: #ddd;
      border: 1px solid #3c3c3c; border-radius: 3px; cursor: pointer;
    }
    .plat button:hover { border-color: #f90; }
    .plat textarea {
      width: 100%; box-sizing: border-box; margin-top: 6px; height: 92px; resize: vertical;
      background: #22252a; color: #ddd; border: 1px solid #3c3c3c; border-radius: 3px;
      font-family: Menlo, monospace; font-size: 11px; padding: 5px; outline: none;
    }
    .plat textarea:focus { border-color: #f90; }
    .plat .hint { color: #666; margin-top: 5px; line-height: 1.5; }

    .foot {
      display: flex; align-items: center; gap: 8px;
      padding: 6px 8px; border-top: 1px solid #2b2b2b; background: #202226;
    }
    .foot .status { flex: 1; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; color: #888; }
    .foot .status.warn { color: #d88; }
    .foot .status.good { color: #6a8; }
    .foot .probe { flex: none; color: #789; cursor: pointer; text-decoration: underline; }
    .foot button {
      flex: none; padding: 4px 10px; font-size: 12px; background: #2f3947; color: #ddd;
      border: 1px solid #3c4759; border-radius: 3px; cursor: pointer;
    }
    .foot button:disabled { opacity: 0.45; cursor: default; }
    .foot button.apply { background: #3a4a2f; border-color: #4d6140; }
    .foot button.apply.armed { background: #6b3a2f; border-color: #8a4a3a; color: #fff; }
  `,

  template: `
    <div class="head">
      <span class="summary" id="summary">no image selected</span>
      <a id="refresh">refresh</a>
    </div>
    <div class="body">
      <div class="section" id="tex-head">Texture</div>
      <div id="tex"></div>
      <div class="section" id="sprite-head">Sprite Frame</div>
      <div id="sprite"></div>
      <div class="section" id="plat-head">Platform Settings (compression)</div>
      <div class="plat" id="plat"></div>
    </div>
    <div class="foot">
      <span class="status" id="status">select images in the Assets panel</span>
      <a class="probe" id="probe">probe</a>
      <button id="revert-all">revert</button>
      <button class="apply" id="apply">Apply</button>
    </div>
  `,

  $: {
    summary: '#summary',
    refresh: '#refresh',
    tex: '#tex',
    texHead: '#tex-head',
    sprite: '#sprite',
    spriteHead: '#sprite-head',
    platHead: '#plat-head',
    plat: '#plat',
    status: '#status',
    probe: '#probe',
    revertAll: '#revert-all',
    apply: '#apply',
  },

  ready () {
    this._assets = [];
    this._skipped = 0;
    this._selection = [];
    this._patch = { texture: {}, sprite: {} };
    this._platformPatch = undefined;
    this._editingJson = false;
    this._jsonDraft = '';
    this._armed = false;
    this._busy = false;
    this._readToken = 0;
    this._statusTimer = null;
    this._syncTimer = null;

    this.$refresh.addEventListener('click', () => this._syncSelection());
    this.$probe.addEventListener('click', () => this._onProbe());
    this.$revertAll.addEventListener('click', () => this._revertAll());
    this.$apply.addEventListener('click', () => this._onApply());

    this._syncSelection();
  },

  // ---------------------------------------------------------------- selection

  /** Assets-panel selection. curActivate covers the single-click-then-open case. */
  _readSelection () {
    let selection = [];
    try {
      selection = Editor.Selection.curSelection('asset') || [];
    } catch (err) {
      selection = [];
    }
    if (!selection.length) {
      try {
        const active = Editor.Selection.curActivate('asset');
        if (active) {
          selection = Array.isArray(active) ? active : [active];
        }
      } catch (err) {
        // no activated asset either
      }
    }
    return selection.filter(Boolean);
  },

  _syncSelection () {
    if (this._busy) {
      return;
    }
    const selection = this._readSelection();
    this._selection = selection;

    if (!selection.length) {
      this._assets = [];
      this._skipped = 0;
      this._render();
      return;
    }

    const token = ++this._readToken;
    Editor.Ipc.sendToMain('sprite-batch:read', selection, (err, data) => {
      if (token !== this._readToken) {
        return; // a newer selection already answered - never let a slow reply win
      }
      if (err) {
        Editor.warn('[sprite-batch] read failed: ' + err);
        this._setStatus('read failed: ' + err + ' - see Console', 'warn');
        return;
      }
      this._assets = (data && data.assets) || [];
      this._skipped = (data && data.skipped) || 0;
      this._armed = false;
      this._render();
    }, IPC_NO_TIMEOUT);
  },

  /** Shift-selecting a folder fires a burst of selection events - collapse them. */
  _queueSync () {
    if (this._syncTimer) {
      clearTimeout(this._syncTimer);
    }
    this._syncTimer = setTimeout(() => {
      this._syncTimer = null;
      this._syncSelection();
    }, 80);
  },

  // ---------------------------------------------------------------- aggregation

  /** One display state for a field across the whole selection. */
  _aggregate (field) {
    if (!this._assets.length) {
      return { state: 'empty' };
    }

    let value;
    let found = false;

    for (let i = 0; i < this._assets.length; ++i) {
      const asset = this._assets[i];
      const raw = field.level === 'texture' ? asset.texture[field.key] : asset.sprite[field.key];
      if (raw === undefined) {
        continue; // e.g. an image with no sprite-frame subMeta
      }
      if (raw === MIXED) {
        return { state: 'mixed' };
      }
      if (!found) {
        value = raw;
        found = true;
      } else if (raw !== value) {
        return { state: 'mixed' };
      }
    }

    return found ? { state: 'value', value: value } : { state: 'empty' };
  },

  _isDirty (field) {
    return Object.prototype.hasOwnProperty.call(this._patch[field.level], field.key);
  },

  _dirtyCount () {
    return Object.keys(this._patch.texture).length
      + Object.keys(this._patch.sprite).length
      + (this._platformPatch === undefined ? 0 : 1);
  },

  // ---------------------------------------------------------------- rendering

  _render () {
    this._renderHead();
    this.$tex.textContent = '';
    this.$sprite.textContent = '';

    FIELDS.forEach((field) => {
      const row = this._buildRow(field);
      (field.level === 'texture' ? this.$tex : this.$sprite).appendChild(row);
    });

    this._renderSectionHead(this.$texHead, 'Texture', Object.keys(this._patch.texture).length);
    this._renderSectionHead(this.$spriteHead, 'Sprite Frame', Object.keys(this._patch.sprite).length);
    this._renderSectionHead(this.$platHead, 'Platform Settings (compression)', this._platformPatch === undefined ? 0 : 1);

    this._renderPlatform();
    this._renderFoot();
  },

  _renderSectionHead (host, title, count) {
    host.textContent = title;
    if (!count) {
      return;
    }
    const badge = document.createElement('span');
    badge.className = 'badge';
    badge.textContent = '  ● ' + count + ' staged';
    host.appendChild(badge);
  },

  _renderHead () {
    const bar = this.$summary;
    if (!this._assets.length) {
      bar.className = 'summary none';
      bar.textContent = this._selection.length
        ? 'selection has no image asset' + (this._skipped ? ' (' + this._skipped + ' skipped)' : '')
        : 'no image selected';
      return;
    }
    bar.className = 'summary';
    bar.textContent = '';
    const strong = document.createElement('b');
    strong.textContent = this._assets.length + ' image' + (this._assets.length === 1 ? '' : 's');
    bar.appendChild(strong);
    const tail = this._assets.length === 1
      ? '  ' + this._assets[0].name
      : (this._skipped ? '  (' + this._skipped + ' non-image skipped)' : '');
    bar.appendChild(document.createTextNode(tail));
    bar.title = this._assets.map(a => a.url || a.name).join('\n');
  },

  _buildRow (field) {
    const row = document.createElement('div');
    row.className = 'row';

    const label = document.createElement('label');
    label.textContent = field.label;
    row.appendChild(label);

    const dirty = this._isDirty(field);
    const agg = this._aggregate(field);
    const control = field.kind === 'number'
      ? this._buildNumber(field, agg, dirty)
      : this._buildSelect(field, agg, dirty);
    control.disabled = !this._assets.length;
    row.appendChild(control);

    if (dirty) {
      const was = document.createElement('span');
      const previous = agg.state === 'value'
        ? (field.kind === 'bool' ? boolLabel(agg.value) : String(agg.value))
        : (agg.state === 'mixed' ? 'mixed' : '-');
      was.className = 'was';
      was.textContent = 'was ' + previous;
      was.title = 'current value on disk: ' + previous;
      row.appendChild(was);
    }

    const revert = document.createElement('a');
    revert.className = 'revert' + (dirty ? '' : ' hidden');
    revert.textContent = '↺';
    revert.title = 'revert this field';
    revert.addEventListener('click', () => {
      delete this._patch[field.level][field.key];
      this._armed = false;
      this._render();
    });
    row.appendChild(revert);

    if (dirty) {
      row.className = 'row dirty';
    }
    return row;
  },

  _buildSelect (field, agg, dirty) {
    const select = document.createElement('select');
    const options = field.kind === 'bool' ? [true, false] : field.options;

    if (!dirty && agg.state !== 'value') {
      const placeholder = document.createElement('option');
      placeholder.value = NO_CHANGE;
      placeholder.textContent = agg.state === 'mixed' ? '—  (mixed)' : '—';
      select.appendChild(placeholder);
    }

    const current = dirty ? this._patch[field.level][field.key] : (agg.state === 'value' ? agg.value : undefined);
    const currentText = current === undefined
      ? undefined
      : (field.kind === 'bool' ? boolLabel(current) : String(current));

    const values = options.map(option => (field.kind === 'bool' ? boolLabel(option) : option));
    if (currentText !== undefined && values.indexOf(currentText) < 0) {
      values.push(currentText); // unknown-but-real value: show it instead of lying
    }

    values.forEach((value) => {
      const el = document.createElement('option');
      el.value = value;
      el.textContent = value;
      select.appendChild(el);
    });
    select.value = currentText === undefined ? NO_CHANGE : currentText;

    select.addEventListener('change', () => {
      if (select.value === NO_CHANGE) {
        return;
      }
      this._patch[field.level][field.key] = field.kind === 'bool' ? select.value === 'true' : select.value;
      this._armed = false;
      this._render();
    });

    return select;
  },

  _buildNumber (field, agg, dirty) {
    const input = document.createElement('input');
    input.type = 'number';
    input.min = '0';

    if (dirty) {
      input.value = String(this._patch[field.level][field.key]);
    } else if (agg.state === 'value') {
      input.value = String(agg.value);
    } else {
      input.value = '';
      input.placeholder = agg.state === 'mixed' ? '—  (mixed)' : '—';
    }

    input.addEventListener('change', () => {
      const raw = input.value.trim();
      if (raw === '') {
        delete this._patch[field.level][field.key];
      } else {
        const parsed = Number(raw);
        if (isNaN(parsed)) {
          this._setStatus(field.label + ': not a number', 'warn');
          return;
        }
        this._patch[field.level][field.key] = parsed;
      }
      this._armed = false;
      this._render();
    });

    return input;
  },

  // ---------------------------------------------------------------- platform settings

  /**
   * platformSettings has no fixed shape we can safely author blind, so this section never
   * invents one: it copies an existing asset's block, clears it, or takes verbatim JSON.
   */
  _renderPlatform () {
    const host = this.$plat;
    host.textContent = '';

    const current = document.createElement('div');
    const distinct = [];
    this._assets.forEach((asset) => {
      if (distinct.indexOf(asset.platform) < 0) {
        distinct.push(asset.platform);
      }
    });

    if (!distinct.length) {
      current.className = 'current';
      current.textContent = '-';
    } else if (distinct.length === 1) {
      current.className = 'current';
      current.textContent = 'current: ';
      const strong = document.createElement('b');
      strong.textContent = shortJson(distinct[0]);
      current.appendChild(strong);
      current.title = distinct[0];
    } else {
      current.className = 'current mixed';
      current.textContent = 'current: ';
      const strong = document.createElement('b');
      strong.textContent = '—  (mixed, ' + distinct.length + ' variants)';
      current.appendChild(strong);
      current.title = distinct.join('\n');
    }
    host.appendChild(current);

    if (this._platformPatch !== undefined) {
      const pending = document.createElement('div');
      pending.className = 'pending';
      pending.textContent = 'will write: ' + shortJson(this._platformPatch);
      pending.title = this._platformPatch;
      host.appendChild(pending);
    }

    const controls = document.createElement('div');
    controls.className = 'controls';

    const copy = document.createElement('select');
    const head = document.createElement('option');
    head.value = NO_CHANGE;
    head.textContent = 'copy from...';
    copy.appendChild(head);
    const sources = this._assets.filter(asset => asset.platform && asset.platform !== '{}');
    sources.forEach((asset, index) => {
      const el = document.createElement('option');
      el.value = String(index);
      el.textContent = asset.name;
      el.title = asset.platform;
      copy.appendChild(el);
    });
    copy.disabled = !sources.length;
    copy.title = sources.length
      ? 'copy this asset\'s compression settings onto the whole selection'
      : 'no selected asset has compression settings yet - set one up in the built-in Inspector first';
    copy.addEventListener('change', () => {
      const picked = sources[Number(copy.value)];
      if (!picked) {
        return;
      }
      this._platformPatch = picked.platform;
      this._editingJson = false;
      this._armed = false;
      this._render();
    });
    controls.appendChild(copy);

    const clear = document.createElement('button');
    clear.textContent = 'clear';
    clear.title = 'write an empty platformSettings ({})';
    clear.disabled = !this._assets.length;
    clear.addEventListener('click', () => {
      this._platformPatch = '{}';
      this._editingJson = false;
      this._armed = false;
      this._render();
    });
    controls.appendChild(clear);

    const edit = document.createElement('button');
    edit.textContent = this._editingJson ? 'close editor' : 'edit JSON';
    edit.disabled = !this._assets.length;
    edit.addEventListener('click', () => {
      this._editingJson = !this._editingJson;
      if (this._editingJson) {
        this._jsonDraft = this._platformPatch !== undefined
          ? this._platformPatch
          : (distinct.length === 1 ? distinct[0] : '{}');
      }
      this._render();
    });
    controls.appendChild(edit);

    if (this._platformPatch !== undefined) {
      const revert = document.createElement('button');
      revert.textContent = '↺ revert';
      revert.addEventListener('click', () => {
        this._platformPatch = undefined;
        this._armed = false;
        this._render();
      });
      controls.appendChild(revert);
    }

    host.appendChild(controls);

    if (this._editingJson) {
      const area = document.createElement('textarea');
      area.spellcheck = false;
      area.value = this._jsonDraft;
      area.addEventListener('input', () => { this._jsonDraft = area.value; });
      host.appendChild(area);

      const apply = document.createElement('button');
      apply.textContent = 'stage this JSON';
      apply.style.marginTop = '6px';
      apply.addEventListener('click', () => {
        let parsed = null;
        try {
          parsed = JSON.parse(this._jsonDraft);
        } catch (err) {
          this._setStatus('invalid JSON: ' + err.message, 'warn');
          return;
        }
        if (!parsed || typeof parsed !== 'object' || Array.isArray(parsed)) {
          this._setStatus('platformSettings must be a JSON object', 'warn');
          return;
        }
        this._platformPatch = JSON.stringify(parsed);
        this._editingJson = false;
        this._armed = false;
        this._render();
      });
      host.appendChild(apply);
    }

    const hint = document.createElement('div');
    hint.className = 'hint';
    hint.textContent = 'Compression settings have no editable schema here - configure one image in the built-in Inspector, then copy it onto the rest.';
    host.appendChild(hint);
  },

  // ---------------------------------------------------------------- apply

  _renderFoot () {
    const count = this._assets.length;
    const fields = this._dirtyCount();

    // sprite -> raw/texture drops the sprite-frame subMeta, and every prefab referencing
    // that frame loses its sprite. Worth a warning before a batch does it 300 times.
    if (Object.prototype.hasOwnProperty.call(this._patch.texture, 'type') && !this._statusTimer) {
      this.$status.className = 'status warn';
      this.$status.textContent = 'Type change drops sprite frames - prefabs referencing them break';
    }
    this.$revertAll.disabled = !fields;
    this.$apply.disabled = this._busy || !count || !fields;
    this.$apply.className = this._armed ? 'apply armed' : 'apply';
    this.$apply.textContent = this._armed
      ? 'confirm ' + count + ' assets'
      : 'Apply' + (fields ? '  (' + fields + ' field' + (fields === 1 ? '' : 's') + ')' : '');
  },

  _revertAll () {
    this._patch = { texture: {}, sprite: {} };
    this._platformPatch = undefined;
    this._armed = false;
    this._render();
  },

  _onApply () {
    if (this._busy || !this._assets.length || !this._dirtyCount()) {
      return;
    }

    // A wrong batch means a wide .meta diff, so anything large asks twice.
    if (this._assets.length >= CONFIRM_ABOVE && !this._armed) {
      this._armed = true;
      this._setStatus('about to change ' + this._assets.length + ' assets - click again to confirm', 'warn');
      this._renderFoot();
      return;
    }

    const patch = { texture: this._patch.texture, sprite: this._patch.sprite };
    if (this._platformPatch !== undefined) {
      patch.platform = this._platformPatch;
    }

    this._busy = true;
    this._armed = false;
    this._renderFoot();
    this._setStatus('applying...');

    Editor.Ipc.sendToMain('sprite-batch:apply', {
      uuids: this._assets.map(asset => asset.uuid),
      patch: patch,
    }, (err, result) => {
      this._busy = false;
      if (err || !result) {
        Editor.warn('[sprite-batch] apply failed: ' + (err || 'no result'));
        this._setStatus('apply failed: ' + (err || 'no result') + ' - see Console', 'warn');
        this._renderFoot();
        return;
      }

      let message = 'changed ' + result.changed + ' / unchanged ' + result.unchanged;
      if (result.skipped) {
        message += ' / skipped ' + result.skipped;
      }
      if (result.failed && result.failed.length) {
        message += ' / FAILED ' + result.failed.length;
        result.failed.forEach((item) => {
          Editor.warn('[sprite-batch] ' + item.url + ': ' + item.reason);
        });
        this._setStatus(message + ' - see Console', 'warn');
      } else {
        this._setStatus(message, 'good');
      }

      this._revertAll();
      this._syncSelection();
    });
  },

  /** Dumps what the panel can and cannot see to the Console - for reporting bugs. */
  _onProbe () {
    const selection = this._readSelection();
    Editor.Ipc.sendToMain('sprite-batch:probe', selection, (err, data) => {  // eslint-disable-line
      if (err) {
        Editor.warn('[sprite-batch] probe failed: ' + err);
        this._setStatus('probe failed - see Console', 'warn');
        return;
      }
      Editor.log('[sprite-batch] probe:\n' + JSON.stringify({
        panelSelection: selection,
        assetsLoaded: this._assets.length,
        skipped: this._skipped,
      }, null, 2) + '\n' + JSON.stringify(data, null, 2));
      this._setStatus('probe printed to Console', 'good');
    }, IPC_NO_TIMEOUT);
  },

  // ---------------------------------------------------------------- status

  _setStatus (text, kind) {
    if (this._statusTimer) {
      clearTimeout(this._statusTimer);
      this._statusTimer = null;
    }
    this.$status.textContent = text;
    this.$status.className = 'status' + (kind ? ' ' + kind : '');
    if (kind === 'good' || kind === 'warn') {
      this._statusTimer = setTimeout(() => {
        this._statusTimer = null;
        this.$status.className = 'status';
        this.$status.textContent = 'select images in the Assets panel';
      }, STATUS_REVERT_MS);
    }
  },

  messages: {
    'selection:selected' () {
      this._queueSync();
    },
    'selection:unselected' () {
      this._queueSync();
    },
    'selection:activated' () {
      this._queueSync();
    },
    'sprite-batch:focus' () {
      this._syncSelection();
    },
    'sprite-batch:progress' (event, payload) {
      if (!payload || !payload.total) {
        return;
      }
      this._setStatus('applying ' + payload.done + ' / ' + payload.total + '  ' + (payload.name || ''));
    },
    'asset-db:asset-changed' () {
      this._queueSync();
    },
  },
});
