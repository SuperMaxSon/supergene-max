'use strict';

/**
 * Sprite Batch - main process side.
 *
 * assetdb only exists here, so the panel asks this file for every read and write.
 *
 * Reads never depend on a single assetdb entry point: 2.4 exposes a different subset of
 * helpers depending on the build, so every lookup has a filesystem fallback (the .meta
 * sitting next to the asset is the same data assetdb would hand back). Writes still go
 * through Editor.assetdb.saveMeta whenever it exists, because the editor caches meta in
 * memory and recomputes derived fields on import.
 */

const Fs = require('fs');
const Path = require('path');

const PKG = 'sprite-batch';

/** Fields living on the texture meta root (importer: texture). */
const TEXTURE_FIELDS = ['type', 'wrapMode', 'filterMode', 'premultiplyAlpha', 'genMipmaps', 'packable'];
/** Fields living on every sprite-frame subMeta. */
const SPRITE_FIELDS = ['trimType', 'trimThreshold'];

const MIXED = '__mixed__';
const IMAGE_EXT = ['.png', '.jpg', '.jpeg', '.webp', '.bmp'];

// ---------------------------------------------------------------- path / uuid lookup

function db () {
  return Editor.assetdb || {};
}

/** _path2uuid is an internal map, but it is the one lookup confirmed present in 2.4 builds. */
function pathMap () {
  const map = db()._path2uuid;
  return (map && typeof map === 'object') ? map : null;
}

function uuidOfEntry (entry) {
  if (!entry) {
    return '';
  }
  return typeof entry === 'string' ? entry : (entry.uuid || '');
}

let reverseCache = null;

/** uuid -> path, built once per expansion so a 500-asset batch is not O(assets x paths). */
function reverseMap () {
  if (reverseCache) {
    return reverseCache;
  }
  reverseCache = {};
  const map = pathMap();
  if (map) {
    Object.keys(map).forEach((path) => {
      const id = uuidOfEntry(map[path]);
      if (id && !reverseCache[id]) {
        reverseCache[id] = path;
      }
    });
  }
  return reverseCache;
}

function fspathOf (uuid) {
  try {
    if (typeof db().uuidToFspath === 'function') {
      const direct = db().uuidToFspath(uuid);
      if (direct) {
        return direct;
      }
    }
  } catch (err) {
    // fall through to the map
  }
  return reverseMap()[uuid] || '';
}

function urlOf (uuid, fspath) {
  try {
    if (typeof db().uuidToUrl === 'function') {
      const direct = db().uuidToUrl(uuid);
      if (direct) {
        return direct;
      }
    }
  } catch (err) {
    // fall through
  }
  try {
    if (fspath && typeof db()._url === 'function') {
      return db()._url(fspath) || '';
    }
  } catch (err) {
    // fall through
  }
  return fspath ? 'db://' + Path.basename(fspath) : '';
}

// ---------------------------------------------------------------- meta read

function readMetaFromDisk (fspath) {
  try {
    return JSON.parse(Fs.readFileSync(fspath + '.meta', 'utf8'));
  } catch (err) {
    return null;
  }
}

/** queryMetaInfoByUuid returns the meta as a JSON string in 2.4, but tolerate an object. */
function parseMetaInfo (info) {
  if (!info) {
    return null;
  }
  const raw = info.json;
  if (typeof raw === 'string') {
    try {
      return JSON.parse(raw);
    } catch (err) {
      return null;
    }
  }
  if (raw && typeof raw === 'object') {
    return raw;
  }
  return null;
}

function queryMetaInfo (uuid) {
  return new Promise((resolve) => {
    if (typeof db().queryMetaInfoByUuid !== 'function') {
      resolve(null);
      return;
    }
    try {
      db().queryMetaInfoByUuid(uuid, (err, info) => resolve(err ? null : info));
    } catch (err) {
      resolve(null);
    }
  });
}

/** assetdb first, the .meta file on disk second. Both describe the same asset. */
async function readMeta (uuid, fspath) {
  const viaDb = parseMetaInfo(await queryMetaInfo(uuid));
  if (viaDb) {
    return viaDb;
  }
  return fspath ? readMetaFromDisk(fspath) : null;
}

// ---------------------------------------------------------------- meta write

function hasSaveMeta () {
  return typeof db().saveMeta === 'function';
}

function saveMetaViaDb (uuid, json) {
  return new Promise((resolve) => {
    if (!hasSaveMeta()) {
      resolve(new Error('assetdb.saveMeta unavailable'));
      return;
    }
    try {
      db().saveMeta(uuid, JSON.stringify(json, null, 2), (err) => resolve(err || null));
    } catch (err) {
      resolve(err);
    }
  });
}

/** Best effort - a failed refresh only means the library artifact lags one reimport behind. */
function refreshAsset (url) {
  return new Promise((resolve) => {
    if (!url || typeof db().refresh !== 'function') {
      resolve();
      return;
    }
    try {
      db().refresh(url, () => resolve());
    } catch (err) {
      resolve();
    }
  });
}

// ---------------------------------------------------------------- selection expansion

function isImagePath (fspath) {
  return IMAGE_EXT.indexOf(Path.extname(fspath).toLowerCase()) >= 0;
}

/** Walk a folder for image assets. Used instead of queryAssets so folders work either way. */
function walkImages (dir, out, depth) {
  if ((depth || 0) > 12) {
    return out; // symlink loops and pathological trees stop here
  }

  let entries = [];
  try {
    entries = Fs.readdirSync(dir);
  } catch (err) {
    return out;
  }

  for (let i = 0; i < entries.length; ++i) {
    const name = entries[i];
    if (name.charAt(0) === '.') {
      continue;
    }
    const full = Path.join(dir, name);
    let stat = null;
    try {
      stat = Fs.statSync(full);
    } catch (err) {
      continue;
    }
    if (stat.isDirectory()) {
      walkImages(full, out, (depth || 0) + 1);
    } else if (isImagePath(full) && Fs.existsSync(full + '.meta')) {
      out.push(full);
    }
  }
  return out;
}

/**
 * Selection uuids -> [{uuid, fspath}]. Folders expand to the images underneath;
 * the uuid of a walked file comes from its own .meta, so no assetdb lookup is needed.
 */
function expandSelection (uuids) {
  reverseCache = null; // the db moves between calls - never reuse a stale path map
  const out = [];
  const seen = new Set();

  const push = (uuid, fspath) => {
    if (!uuid || seen.has(uuid)) {
      return;
    }
    seen.add(uuid);
    out.push({ uuid: uuid, fspath: fspath });
  };

  for (let i = 0; i < uuids.length; ++i) {
    const uuid = uuids[i];
    if (!uuid) {
      continue;
    }
    const fspath = fspathOf(uuid);

    let isDir = false;
    try {
      isDir = !!fspath && Fs.statSync(fspath).isDirectory();
    } catch (err) {
      isDir = false;
    }

    if (!isDir) {
      push(uuid, fspath);
      continue;
    }

    const files = walkImages(fspath, [], 0);
    for (let j = 0; j < files.length; ++j) {
      const meta = readMetaFromDisk(files[j]);
      if (meta && meta.uuid) {
        push(meta.uuid, files[j]);
      }
    }
  }

  return out;
}

/**
 * One value for a sprite-frame field across every subMeta of a single image.
 * An image whose frames disagree already counts as mixed.
 */
function collectSpriteValue (json, key) {
  const subMetas = json.subMetas || {};
  const names = Object.keys(subMetas);
  let value;
  let found = false;

  for (let i = 0; i < names.length; ++i) {
    const sub = subMetas[names[i]];
    if (!sub || sub.importer !== 'sprite-frame') {
      continue;
    }
    if (!found) {
      value = sub[key];
      found = true;
    } else if (sub[key] !== value) {
      return MIXED;
    }
  }

  return found ? value : undefined;
}

async function readAssets (uuids) {
  const targets = expandSelection(uuids);
  const assets = [];
  let skipped = 0;

  for (let i = 0; i < targets.length; ++i) {
    const target = targets[i];
    const json = await readMeta(target.uuid, target.fspath);
    if (!json || json.importer !== 'texture') {
      skipped += 1;
      continue;
    }

    const texture = {};
    TEXTURE_FIELDS.forEach((key) => { texture[key] = json[key]; });

    const sprite = {};
    SPRITE_FIELDS.forEach((key) => { sprite[key] = collectSpriteValue(json, key); });

    const url = urlOf(target.uuid, target.fspath);
    assets.push({
      uuid: target.uuid,
      url: url,
      name: target.fspath ? Path.basename(target.fspath) : (url || target.uuid),
      texture: texture,
      sprite: sprite,
      platform: JSON.stringify(json.platformSettings || {}),
    });
  }

  return { assets: assets, skipped: skipped };
}

// ---------------------------------------------------------------- writing

/**
 * Mutates json in place with the dirty fields only. Untouched fields keep each asset's
 * own value - that is the whole point of the Unity-style multi-edit.
 */
function applyPatch (json, patch) {
  const texture = patch.texture || {};
  Object.keys(texture).forEach((key) => { json[key] = texture[key]; });

  if (typeof patch.platform === 'string') {
    let parsed = null;
    try {
      parsed = JSON.parse(patch.platform);
    } catch (err) {
      parsed = null;
    }
    if (parsed && typeof parsed === 'object' && !Array.isArray(parsed)) {
      json.platformSettings = parsed;
    }
  }

  const sprite = patch.sprite || {};
  const spriteKeys = Object.keys(sprite);
  if (!spriteKeys.length || !json.subMetas) {
    return;
  }

  Object.keys(json.subMetas).forEach((name) => {
    const sub = json.subMetas[name];
    if (!sub || sub.importer !== 'sprite-frame') {
      return;
    }
    spriteKeys.forEach((key) => { sub[key] = sprite[key]; });

    // "none" has a known rect: the whole image. "auto"/"custom" are recomputed on reimport.
    if (sprite.trimType === 'none') {
      sub.trimX = 0;
      sub.trimY = 0;
      sub.offsetX = 0;
      sub.offsetY = 0;
      if (typeof sub.rawWidth === 'number') {
        sub.width = sub.rawWidth;
      }
      if (typeof sub.rawHeight === 'number') {
        sub.height = sub.rawHeight;
      }
    }
  });
}

function report (payload) {
  try {
    Editor.Ipc.sendToPanel(PKG, PKG + ':progress', payload);
  } catch (err) {
    // panel closed mid-batch - the writes keep going
  }
}

async function applyToSelection (uuids, patch) {
  const targets = expandSelection(uuids);
  const result = { total: targets.length, changed: 0, unchanged: 0, skipped: 0, failed: [] };

  for (let i = 0; i < targets.length; ++i) {
    const target = targets[i];
    const url = urlOf(target.uuid, target.fspath);
    const json = await readMeta(target.uuid, target.fspath);

    if (!json || json.importer !== 'texture') {
      result.skipped += 1;
      report({ done: i + 1, total: targets.length, name: url });
      continue;
    }

    const before = JSON.stringify(json);
    applyPatch(json, patch);

    if (JSON.stringify(json) === before) {
      result.unchanged += 1; // nothing to write - skip the reimport cost entirely
      report({ done: i + 1, total: targets.length, name: url });
      continue;
    }

    let err = await saveMetaViaDb(target.uuid, json);

    // Last resort ONLY when the editor has no saveMeta at all. If saveMeta exists and
    // refused, that refusal is meaningful - writing the file behind it would desync the
    // editor's in-memory meta cache.
    if (err && !hasSaveMeta() && target.fspath) {
      try {
        Fs.writeFileSync(target.fspath + '.meta', JSON.stringify(json, null, 2));
        err = null;
      } catch (writeErr) {
        err = writeErr;
      }
    }

    if (err) {
      result.failed.push({ url: url, reason: String((err && err.message) || err) });
    } else {
      result.changed += 1;
      await refreshAsset(url);
    }
    report({ done: i + 1, total: targets.length, name: url });
  }

  return result;
}

// ---------------------------------------------------------------- diagnostics

async function probe (uuids) {
  const api = {};
  ['queryMetaInfoByUuid', 'saveMeta', 'refresh', 'uuidToUrl', 'uuidToFspath', 'queryAssets', '_url']
    .forEach((name) => { api[name] = typeof db()[name]; });
  api._path2uuid = pathMap() ? Object.keys(pathMap()).length + ' entries' : 'missing';

  const targets = expandSelection(uuids || []);
  const sample = [];
  for (let i = 0; i < Math.min(targets.length, 3); ++i) {
    const target = targets[i];
    const viaDb = parseMetaInfo(await queryMetaInfo(target.uuid));
    const viaDisk = target.fspath ? readMetaFromDisk(target.fspath) : null;
    sample.push({
      uuid: target.uuid,
      fspath: target.fspath || '(not resolved)',
      metaViaAssetdb: viaDb ? viaDb.importer : 'null',
      metaViaDisk: viaDisk ? viaDisk.importer : 'null',
    });
  }

  return {
    selectionCount: (uuids || []).length,
    expandedCount: targets.length,
    api: api,
    sample: sample,
  };
}

// ---------------------------------------------------------------- package entry

function replyWith (event, promise) {
  promise.then((data) => {
    if (event && typeof event.reply === 'function') {
      event.reply(null, data);
    }
  }).catch((err) => {
    Editor.warn('[' + PKG + '] ' + ((err && err.stack) || err));
    if (event && typeof event.reply === 'function') {
      event.reply(String((err && err.message) || err));
    }
  });
}

module.exports = {
  load () {
    Editor.log('[' + PKG + '] package loaded');
  },

  unload () {
  },

  messages: {
    'open' () {
      Editor.Panel.open(PKG);
      // Already-open panels do not run ready() again - nudge them to re-read the selection.
      Editor.Ipc.sendToPanel(PKG, PKG + ':focus');
    },

    'read' (event, uuids) {
      replyWith(event, readAssets(Array.isArray(uuids) ? uuids : []));
    },

    'apply' (event, payload) {
      const uuids = (payload && Array.isArray(payload.uuids)) ? payload.uuids : [];
      const patch = (payload && payload.patch) || {};
      replyWith(event, applyToSelection(uuids, patch));
    },

    'probe' (event, uuids) {
      replyWith(event, probe(Array.isArray(uuids) ? uuids : []));
    },
  },
};
