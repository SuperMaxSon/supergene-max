@echo off
setlocal
cd /d "%~dp0"

set "PKG=sprite-batch"
set "DEST_DIR=%USERPROFILE%\.CocosCreator\packages"
set "DEST=%DEST_DIR%\%PKG%"
set "BACKUP=%DEST%.bak"

echo ================================================
echo  Sprite Batch - uninstaller   (by Max)
echo ================================================
echo.

set "FOUND="
if exist "%DEST%" set "FOUND=1"
if exist "%BACKUP%" set "FOUND=1"
if not defined FOUND goto none

echo  these folders will be deleted:
if exist "%DEST%"   echo    - %DEST%
if exist "%BACKUP%" echo    - %BACKUP%
echo.

set "ANS=n"
set /p "ANS=delete? [y/N] "
if /i not "%ANS%"=="y" goto cancelled

if exist "%DEST%"   rmdir /s /q "%DEST%"
if exist "%BACKUP%" rmdir /s /q "%BACKUP%"
if exist "%DEST%" goto err_locked

echo.
echo  [OK] removed
echo  Restart Cocos Creator and the extension is gone.
echo  To install again, run install_win.bat in this folder.
goto done

:none
echo  Not installed - nothing to remove.
echo  checked: %DEST%
goto done

:cancelled
echo  Cancelled. Nothing was deleted.
goto done

:err_locked
echo  [ERROR] could not delete - Cocos Creator may still be running.
echo  Quit Cocos Creator and run this file again.
echo.
pause
exit /b 1

:done
echo.
pause
exit /b 0
