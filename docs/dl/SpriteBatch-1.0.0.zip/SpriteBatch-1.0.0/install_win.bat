@echo off
setlocal
cd /d "%~dp0"

set "PKG=sprite-batch"
set "SRC=%~dp0%PKG%"
set "DEST_DIR=%USERPROFILE%\.CocosCreator\packages"
set "DEST=%DEST_DIR%\%PKG%"

echo ================================================
echo  Sprite Batch - Cocos Creator 2.4 extension
echo  Windows installer   (by Max)
echo ================================================
echo.
echo  source : %SRC%
echo  target : %DEST%
echo.

rem --- running straight out of the zip is the usual failure, so check it first
echo "%~dp0" | find /i "\AppData\Local\Temp\" >nul
if not errorlevel 1 goto err_temp

if not exist "%SRC%\package.json" goto err_nosrc

if not exist "%DEST_DIR%" mkdir "%DEST_DIR%" 2>nul
if not exist "%DEST_DIR%" goto err_mkdir

if not exist "%DEST%" goto copy

rem --- replace an existing install, keeping one backup
if exist "%DEST%.bak" rmdir /s /q "%DEST%.bak"
move /y "%DEST%" "%DEST%.bak" >nul
if errorlevel 1 goto err_backup
echo  previous version backed up to: %DEST%.bak

:copy
xcopy /E /I /Y /Q "%SRC%" "%DEST%\" >nul
if errorlevel 1 goto err_copy
if not exist "%DEST%\package.json" goto err_copy

echo.
echo  [OK] installed
echo.
echo  next steps:
echo    1) quit Cocos Creator completely, then start it again
echo    2) Console should print:  [sprite-batch] package loaded
echo    3) select images in the Assets panel, press  Ctrl + Shift + S
goto done

:err_temp
echo  [ERROR] running from a temporary folder.
echo.
echo  You opened this file inside the zip.
echo  Extract the zip to a real folder first (Desktop is fine),
echo  then run this file from the extracted folder.
goto fail

:err_nosrc
echo  [ERROR] "%PKG%" folder not found next to this file.
echo.
echo  This installer must sit in the same folder as the
echo  "%PKG%" folder. Extract the whole zip and try again.
goto fail

:err_mkdir
echo  [ERROR] could not create: %DEST_DIR%
goto fail

:err_backup
echo  [ERROR] could not back up the existing install.
echo  Close Cocos Creator and run this file again.
goto fail

:err_copy
echo  [ERROR] copy failed.
echo  Close Cocos Creator and run this file again.
echo  If it keeps failing, copy the "%PKG%" folder manually into:
echo    %DEST_DIR%
goto fail

:fail
echo.
pause
exit /b 1

:done
echo.
pause
exit /b 0
