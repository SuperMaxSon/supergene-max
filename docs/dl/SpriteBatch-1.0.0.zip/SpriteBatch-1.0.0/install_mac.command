#!/usr/bin/env bash
# Sprite Batch - Cocos Creator 2.4 확장 설치 프로그램 (macOS)
# 이 파일을 더블클릭하면 모든 프로젝트에서 쓸 수 있도록 전역 설치됩니다.

cd "$(dirname "$0")" || exit 1
HERE="$PWD"

PKG_NAME="sprite-batch"
SRC="$HERE/$PKG_NAME"
DEST_DIR="$HOME/.CocosCreator/packages"
DEST="$DEST_DIR/$PKG_NAME"

# 터미널 기본 설정이 "쉘 종료 시 창 유지"라 스크립트가 끝나도 창은 남는다.
# 자동으로 닫으려면 터미널 자동화 권한 승인 창이 뜨는데, 배포용으로는 그게 더 번거로워서
# 문구로만 안내한다.
finish () {
  echo
  if [ -t 0 ]; then
    read -n 1 -r -p "확인했으면 아무 키나 누르세요. (이 창은 Cmd + W 로 닫으시면 됩니다)"
    echo
  fi
  exit "${1:-0}"
}

echo "Sprite Batch - Cocos Creator 2.4 확장  (제작: Max)"
echo

# 내려받은 zip 에서 풀린 파일에 붙는 격리 속성 제거 (없으면 조용히 통과)
xattr -dr com.apple.quarantine "$HERE" 2>/dev/null

if [ ! -f "$SRC/package.json" ]; then
  echo "설치 파일을 찾지 못했습니다: $SRC"
  echo "압축을 먼저 풀고, 풀린 폴더 안의 이 파일을 실행해 주세요."
  finish 1
fi

mkdir -p "$DEST_DIR" || { echo "폴더를 만들지 못했습니다: $DEST_DIR"; finish 1; }

# 기존 설치본은 묻지 않고 .bak 으로 백업 후 교체
if [ -e "$DEST" ]; then
  rm -rf "$DEST.bak"
  mv "$DEST" "$DEST.bak" || { echo "기존 설치본 백업에 실패했습니다."; finish 1; }
  echo "기존 버전을 백업했습니다 -> $DEST.bak"
fi

cp -R "$SRC" "$DEST" || { echo "복사에 실패했습니다."; finish 1; }
xattr -dr com.apple.quarantine "$DEST" 2>/dev/null

VERSION=$(sed -n 's/.*"version"[[:space:]]*:[[:space:]]*"\([^"]*\)".*/\1/p' "$DEST/package.json" | head -1)

echo "설치 완료 (v${VERSION:-?}) -> $DEST"
echo
echo "다음 순서로 확인해 주세요."
echo "  1) Cocos Creator 를 완전히 종료했다가 다시 실행"
echo "  2) Console 에 [sprite-batch] package loaded 가 보이는지 확인"
echo "  3) Assets 패널에서 이미지 여러 장 선택하고 Shift + Cmd + S"
finish 0
